# `Deployed @`[`pythonanywhere`](https://heyvicks.pythonanywhere.com/)

    unzip /home/heyvicks/app.zip
    find /home/heyvicks -type d -exec chmod 755 {} +
    zip -r project.zip .

![image](https://github.com/user-attachments/assets/f3b1ecef-bde1-4825-b4d6-57a6b845c318)
![image](https://github.com/user-attachments/assets/aca4b4f8-20ab-4518-8ae7-b496b457c466)
![image](https://github.com/user-attachments/assets/1704c449-8f53-432d-afe3-99c66a6809d8)
